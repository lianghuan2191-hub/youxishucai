1 Wings
2 Floral
3 Cursed Relic
4 Sacred Relic
5 Edible
6 Smoke
7 Moon
8 Sun
9 Ocean
10 Ceremony/Ritual
11 Duel
12 Fire
13 Ice
14 Poisoned
15 Liquid
16 Tooth/Bone
17 Glass
18 Jester
19 Forest
20 Shattered
21 Eyes
22 Mechanical
23 Summoned/Banished
24 Incrusted
25 Woven
26 Storm
27 Insect
28 Crystal
29 Necromancer
30Glowing